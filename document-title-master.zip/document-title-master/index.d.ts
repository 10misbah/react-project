interface DocumentTitle {}

export default function useDocumentTitle(title: string): DocumentTitle;
